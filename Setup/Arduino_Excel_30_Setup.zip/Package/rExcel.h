
/*
rExcel.h - Library for Arduino Excel data exchange 
Created by Roberto Valgolio, 20/06/2016

Released into the public domain

History

14/07/2016	added 1ms delay in clearInput()
21/07/2016	ACK/NAK protocol that makes all very stable
25/02/2017	added comments on get methods
02/03/2017	added comment on readMessage()
09/06/2017	added up() function
17/07/2017	see Michael Peter Allan suggestions
08/10/2017	added mail() function
04/05/2019	added send() function, thanks Peter Kowald
03/12/2019	modified mail() function
03/12/2019	added log() function


*/

#ifndef rExcel_h
#define rExcel_h

#include "Arduino.h"								// without it: 'Serial' was not declared in this scope

#define ATMEL_COMPATIBLE							// comment this define if your Arduino isn't Atmel compatible like Arduino Due or Intel Edison

const int	XLS_BUFFER_SIZE = 32;					// buffer size for input
const int	XLS_MAX_ARGS = 5;						// max CSV message args for input
const int	XLS_TIMEOUT = 500;						// reading timeout ms
const int	XLS_MAX_TRIES = 1;						// protocol tries, set 1 for up() function
const char	XLS_ACK = 0x06;							// positive acknowledgement
const char	XLS_NAK = 0x15;							// negative acknowledgement


class rExcel
{

public:

	rExcel();
	bool	up();
	bool	write(char* worksheet, char* range, int   value);
	bool	write(char* worksheet, char* range, long  value);
	bool	write(char* worksheet, char* range, float value, int decimals);
	bool	write(char* worksheet, char* range, char* value);
	bool	writeIndexed(char* worksheet, unsigned int row, unsigned int column, int   value);
	bool	writeIndexed(char* worksheet, unsigned int row, unsigned int column, long  value);
	bool	writeIndexed(char* worksheet, unsigned int row, unsigned int column, float value, int decimals);
	bool	writeIndexed(char* worksheet, unsigned int row, unsigned int column, char* value);
	bool	send(char* data);
	bool	get(char* worksheet, char* range, char* buffer);
	bool	getIndexed(char* worksheet, unsigned int row, unsigned int column, char* buffer);
	bool	clear(char* worksheet, char* range);
	bool	save();
	bool	mail(char* recipient, char* recipientCc, char* subject, char* body, char* attach);
	bool	log(char* info);
	int		read(char* worksheet, char* range, unsigned int* row, unsigned int* column, char* buffer, char mode);
	void	clearInput();

private:

	int		readMessage(byte* startAddr, int nBytes, int timeout, bool lineBreak);
	int		mapArgs(char* startAddr, int nBytes, char** argPointer, int maxArgs);
	void	clearBuffer(byte* startAddr, int nBytes);

	char	_buffer[16];
	char	_str[6];
	char	_serialBuffer[XLS_BUFFER_SIZE];		// buffer for input
	char*	_serialArgs[XLS_MAX_ARGS];			// args pointers

};

#endif